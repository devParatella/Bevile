module.exports = function (txt: string) {
  return txt;
};
