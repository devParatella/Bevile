// DO NOT delete this file. It is used by vitest to mock the dagre-d3 module.
