export {};

declare global {
  interface Window {
    mermaid: any; // 👈️ turn off type checking
  }
}
